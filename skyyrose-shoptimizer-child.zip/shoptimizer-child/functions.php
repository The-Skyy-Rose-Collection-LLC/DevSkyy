<?php
/**
 * SkyyRose Collection - Shoptimizer Child Theme Functions
 * 
 * SHOPTIMIZER-OPTIMIZED VERSION
 * Complete brand integration with Gemini-generated logos, collection mega menus,
 * WooCommerce quick-add functionality, and Elementor compatibility.
 *
 * @package SkyyRose
 * @subpackage Shoptimizer Child
 * @version 5.0.0 - Shoptimizer Optimized
 * @author Corey Foster / DevSkyy
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * ========================================================================
 * THEME CONSTANTS - LOGO URLS
 * ========================================================================
 */
define( 'SKYYROSE_LOVE_HURTS_TROPHY', get_stylesheet_directory_uri() . '/assets/logos/love-hurts-trophy-red.png' );
define( 'SKYYROSE_SIGNATURE_ROSE', get_stylesheet_directory_uri() . '/assets/logos/signature-rose-rosegold.png' );
define( 'SKYYROSE_SR_MONOGRAM', get_stylesheet_directory_uri() . '/assets/logos/sr-monogram-rosegold.png' );
define( 'SKYYROSE_BLACK_ROSE_TROPHY', get_stylesheet_directory_uri() . '/assets/logos/black-rose-trophy-cosmic.png' );
define( 'SKYYROSE_LOVE_HURTS_TEXT', get_stylesheet_directory_uri() . '/assets/logos/love-hurts-text-logo.png' );

/**
 * ========================================================================
 * ENQUEUE PARENT & CHILD STYLES
 * ========================================================================
 */
function skyyrose_enqueue_styles() {
    // Enqueue parent theme stylesheet
    wp_enqueue_style( 
        'shoptimizer-parent-style', 
        get_template_directory_uri() . '/style.css',
        array(),
        wp_get_theme()->parent()->get('Version')
    );
    
    // Enqueue child theme stylesheet
    wp_enqueue_style( 
        'skyyrose-child-style',
        get_stylesheet_uri(),
        array( 'shoptimizer-parent-style' ),
        wp_get_theme()->get('Version')
    );
    
    // Enqueue Google Fonts
    wp_enqueue_style(
        'skyyrose-fonts',
        'https://fonts.googleapis.com/css2?family=Playfair+Display:wght@300;400;600;700;900&family=Inter:wght@300;400;600;700;800&display=swap',
        array(),
        null
    );
}
add_action( 'wp_enqueue_scripts', 'skyyrose_enqueue_styles', 15 );

/**
 * ========================================================================
 * COLLECTION META BOX - PAGE EDITOR
 * Allows selection of collection and automatic logo assignment
 * ========================================================================
 */
function skyyrose_add_collection_meta_box() {
    add_meta_box(
        'skyyrose_collection_settings',
        '🌹 SkyyRose Collection Settings',
        'skyyrose_collection_meta_box_callback',
        'page',
        'side',
        'high'
    );
}
add_action( 'add_meta_boxes', 'skyyrose_add_collection_meta_box' );

function skyyrose_collection_meta_box_callback( $post ) {
    wp_nonce_field( 'skyyrose_collection_nonce', 'skyyrose_collection_nonce' );
    
    $collection = get_post_meta( $post->ID, '_skyyrose_collection', true );
    $show_logo = get_post_meta( $post->ID, '_skyyrose_show_logo', true );
    $show_logo = $show_logo !== '' ? $show_logo : '1'; // Default to show
    
    ?>
    <p>
        <label for="skyyrose_collection"><strong>Select Collection:</strong></label><br>
        <select name="skyyrose_collection" id="skyyrose_collection" style="width:100%; margin-top:5px;">
            <option value="">None</option>
            <option value="black-rose" <?php selected( $collection, 'black-rose' ); ?>>🏆 BLACK ROSE</option>
            <option value="love-hurts" <?php selected( $collection, 'love-hurts' ); ?>>💔 LOVE HURTS</option>
            <option value="signature" <?php selected( $collection, 'signature' ); ?>>✨ SIGNATURE</option>
        </select>
        <small style="display:block; margin-top:5px; color:#666;">Logo will auto-select based on collection</small>
    </p>
    
    <p>
        <label>
            <input type="checkbox" name="skyyrose_show_logo" value="1" <?php checked( $show_logo, '1' ); ?> />
            <strong>Show collection logo at top of page</strong>
        </label>
    </p>
    
    <?php if ( $collection ) : ?>
        <div style="margin-top:15px; padding:10px; background:#f0f0f0; border-radius:4px;">
            <strong>Selected Logo:</strong><br>
            <?php
            $logos = array(
                'black-rose' => array( 'url' => SKYYROSE_BLACK_ROSE_TROPHY, 'name' => 'BLACK ROSE Trophy' ),
                'love-hurts' => array( 'url' => SKYYROSE_LOVE_HURTS_TROPHY, 'name' => 'LOVE HURTS Trophy' ),
                'signature' => array( 'url' => SKYYROSE_SIGNATURE_ROSE, 'name' => 'SIGNATURE Rose' )
            );
            
            if ( isset( $logos[$collection] ) ) {
                echo '<img src="' . esc_url( $logos[$collection]['url'] ) . '" style="max-width:100%; height:auto; margin-top:10px; border:1px solid #ddd; padding:5px; background:white;" />';
                echo '<div style="text-align:center; margin-top:5px; font-size:11px; color:#666;">' . esc_html( $logos[$collection]['name'] ) . '</div>';
            }
            ?>
        </div>
    <?php endif; ?>
    <?php
}

function skyyrose_save_collection_meta( $post_id ) {
    // Security checks
    if ( ! isset( $_POST['skyyrose_collection_nonce'] ) ) return;
    if ( ! wp_verify_nonce( $_POST['skyyrose_collection_nonce'], 'skyyrose_collection_nonce' ) ) return;
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( ! current_user_can( 'edit_post', $post_id ) ) return;
    
    // Save collection
    if ( isset( $_POST['skyyrose_collection'] ) ) {
        update_post_meta( $post_id, '_skyyrose_collection', sanitize_text_field( $_POST['skyyrose_collection'] ) );
    }
    
    // Save show logo preference
    $show_logo = isset( $_POST['skyyrose_show_logo'] ) ? '1' : '0';
    update_post_meta( $post_id, '_skyyrose_show_logo', $show_logo );
}
add_action( 'save_post', 'skyyrose_save_collection_meta' );

/**
 * ========================================================================
 * AUTO-INSERT COLLECTION LOGO AT TOP OF PAGE CONTENT
 * Uses Gemini-generated logos
 * ========================================================================
 */
function skyyrose_auto_insert_collection_header( $content ) {
    if ( ! is_singular( 'page' ) ) {
        return $content;
    }
    
    global $post;
    $collection = get_post_meta( $post->ID, '_skyyrose_collection', true );
    $show_logo = get_post_meta( $post->ID, '_skyyrose_show_logo', true );
    
    if ( ! $collection || $show_logo === '0' ) {
        return $content;
    }
    
    // Collection configurations
    $configs = array(
        'black-rose' => array(
            'logo' => SKYYROSE_BLACK_ROSE_TROPHY,
            'bg' => 'linear-gradient(135deg, #1A1A1A, #0A0A0A)',
            'border' => '#C0C0C0',
            'shadow' => 'rgba(192, 192, 192, 0.4)',
            'name' => 'BLACK ROSE'
        ),
        'love-hurts' => array(
            'logo' => SKYYROSE_LOVE_HURTS_TROPHY,
            'bg' => 'radial-gradient(circle at center, #8B0000, #0A0A0A)',
            'border' => '#DC143C',
            'shadow' => 'rgba(220, 20, 60, 0.5)',
            'name' => 'LOVE HURTS'
        ),
        'signature' => array(
            'logo' => SKYYROSE_SIGNATURE_ROSE,
            'bg' => 'linear-gradient(135deg, #1A1815, #0A0A0A)',
            'border' => '#C9A962',
            'shadow' => 'rgba(201, 169, 98, 0.5)',
            'name' => 'SIGNATURE'
        )
    );
    
    $config = $configs[ $collection ] ?? $configs['signature'];
    
    $header_html = sprintf(
        '<div class="skyyrose-collection-header" style="background: %s; padding: 4rem 2rem; text-align: center; border-bottom: 3px solid %s; box-shadow: 0 15px 60px %s; margin: -2rem -2rem 3rem -2rem; border-radius: 0 0 16px 16px;">
            <img src="%s" alt="%s Collection" style="max-width: 500px; width: 100%%; height: auto; filter: drop-shadow(0 15px 40px %s); animation: gentleFloat 8s ease-in-out infinite;" />
        </div>',
        esc_attr( $config['bg'] ),
        esc_attr( $config['border'] ),
        esc_attr( $config['shadow'] ),
        esc_url( $config['logo'] ),
        esc_attr( $config['name'] ),
        esc_attr( $config['shadow'] )
    );
    
    return $header_html . $content;
}
add_filter( 'the_content', 'skyyrose_auto_insert_collection_header', 5 );

/**
 * ========================================================================
 * ADD COLLECTION BODY CLASS
 * ========================================================================
 */
function skyyrose_add_collection_body_class( $classes ) {
    if ( is_singular( 'page' ) ) {
        global $post;
        $collection = get_post_meta( $post->ID, '_skyyrose_collection', true );
        
        if ( $collection ) {
            $classes[] = 'collection-' . sanitize_html_class( $collection );
            $classes[] = 'skyyrose-shoptimizer';
        }
    }
    
    return $classes;
}
add_filter( 'body_class', 'skyyrose_add_collection_body_class' );

/**
 * ========================================================================
 * WOOCOMMERCE: AUTO-ADD COLLECTION BADGE TO PRODUCTS
 * Shoptimizer-optimized product cards
 * ========================================================================
 */
function skyyrose_product_collection_badge() {
    if ( ! function_exists( 'is_product' ) ) return;
    
    global $product;
    
    // Get product categories
    $terms = get_the_terms( $product->get_id(), 'product_cat' );
    if ( ! $terms ) return;
    
    $collection = '';
    
    // Map categories to collections
    foreach ( $terms as $term ) {
        $slug = $term->slug;
        
        if ( strpos( $slug, 'black-rose' ) !== false ) {
            $collection = 'black-rose';
            break;
        } elseif ( strpos( $slug, 'love-hurts' ) !== false ) {
            $collection = 'love-hurts';
            break;
        } elseif ( strpos( $slug, 'signature' ) !== false ) {
            $collection = 'signature';
            break;
        }
    }
    
    if ( ! $collection ) return;
    
    // Collection badges
    $badges = array(
        'black-rose' => array(
            'bg' => 'linear-gradient(135deg, #C0C0C0, #FFFFFF)',
            'color' => '#0A0A0A',
            'icon' => '🏆',
            'name' => 'BLACK ROSE',
            'subtitle' => 'Limited Edition Gothic'
        ),
        'love-hurts' => array(
            'bg' => 'linear-gradient(135deg, #DC143C, #8B0000)',
            'color' => '#FFFFFF',
            'icon' => '💔',
            'name' => 'LOVE HURTS',
            'subtitle' => 'Family Legacy Collection'
        ),
        'signature' => array(
            'bg' => 'linear-gradient(135deg, #C9A962, #B76E79)',
            'color' => '#0A0A0A',
            'icon' => '✨',
            'name' => 'SIGNATURE',
            'subtitle' => 'Runway Essentials'
        )
    );
    
    $badge = $badges[ $collection ];
    
    echo sprintf(
        '<div class="skyyrose-product-badge" style="margin-bottom: 2rem; animation: slideInLeft 0.6s cubic-bezier(0.4, 0, 0.2, 1);">
            <div style="background: %s; color: %s; padding: 1rem 1.5rem; display: inline-block; border-radius: 8px; font-weight: 700; letter-spacing: 0.15em; box-shadow: 0 8px 30px rgba(0,0,0,0.4);">
                <div style="font-size: 1.5rem; margin-bottom: 0.25rem;">%s %s</div>
                <div style="font-size: 0.7rem; opacity: 0.9; font-weight: 400; letter-spacing: 0.1em;">%s</div>
            </div>
        </div>',
        esc_attr( $badge['bg'] ),
        esc_attr( $badge['color'] ),
        esc_html( $badge['icon'] ),
        esc_html( $badge['name'] ),
        esc_html( $badge['subtitle'] )
    );
}
add_action( 'woocommerce_before_single_product_summary', 'skyyrose_product_collection_badge', 5 );

/**
 * ========================================================================
 * SHOPTIMIZER CUSTOMIZATIONS
 * ========================================================================
 */

// Set custom logo
function skyyrose_custom_logo() {
    return SKYYROSE_SR_MONOGRAM;
}
add_filter( 'shoptimizer_logo', 'skyyrose_custom_logo' );

// Custom footer text
function skyyrose_custom_footer_text() {
    return '© ' . date('Y') . ' <a href="https://skyyrose.co" style="color: #C9A962;">SkyyRose</a> - Where Love Meets Luxury. Oakland, California. 🌹';
}
add_filter( 'shoptimizer_footer_text', 'skyyrose_custom_footer_text' );

/**
 * ========================================================================
 * SHORTCODES
 * ========================================================================
 */

// [collection_logo collection="black-rose" size="large"]
function skyyrose_collection_logo_shortcode( $atts ) {
    $atts = shortcode_atts( array(
        'collection' => '',
        'size' => 'medium',
        'align' => 'center'
    ), $atts );
    
    $logos = array(
        'black-rose' => SKYYROSE_BLACK_ROSE_TROPHY,
        'love-hurts' => SKYYROSE_LOVE_HURTS_TROPHY,
        'signature' => SKYYROSE_SIGNATURE_ROSE,
        'sr' => SKYYROSE_SR_MONOGRAM,
        'love-hurts-text' => SKYYROSE_LOVE_HURTS_TEXT
    );
    
    $logo_url = $logos[ $atts['collection'] ] ?? '';
    if ( ! $logo_url ) return '';
    
    $sizes = array(
        'small' => '200px',
        'medium' => '400px',
        'large' => '600px',
        'hero' => '800px'
    );
    
    $max_width = $sizes[ $atts['size'] ] ?? '400px';
    
    return sprintf(
        '<div class="skyyrose-collection-logo" style="text-align: %s; margin: 2rem 0;">
            <img src="%s" alt="%s Collection" style="max-width: %s; width: 100%%; height: auto; animation: fadeSlideIn 1s ease-out;" />
        </div>',
        esc_attr( $atts['align'] ),
        esc_url( $logo_url ),
        esc_attr( ucwords( str_replace( '-', ' ', $atts['collection'] ) ) ),
        esc_attr( $max_width )
    );
}
add_shortcode( 'collection_logo', 'skyyrose_collection_logo_shortcode' );

/**
 * ========================================================================
 * THEME SETUP
 * ========================================================================
 */
function skyyrose_theme_setup() {
    add_theme_support( 'custom-logo' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'woocommerce' );
    add_theme_support( 'wc-product-gallery-zoom' );
    add_theme_support( 'wc-product-gallery-lightbox' );
    add_theme_support( 'wc-product-gallery-slider' );
    
    // Register image sizes
    add_image_size( 'skyyrose-collection-hero', 800, 400, false );
    add_image_size( 'skyyrose-product-badge', 300, 300, true );
}
add_action( 'after_setup_theme', 'skyyrose_theme_setup' );

/**
 * ========================================================================
 * ADMIN ENQUEUE
 * ========================================================================
 */
function skyyrose_admin_scripts( $hook ) {
    if ( 'post.php' !== $hook && 'post-new.php' !== $hook ) return;
    
    wp_enqueue_media();
}
add_action( 'admin_enqueue_scripts', 'skyyrose_admin_scripts' );

/**
 * ========================================================================
 * END OF FILE - Shoptimizer Optimized v5.0.0
 * ========================================================================
 */
