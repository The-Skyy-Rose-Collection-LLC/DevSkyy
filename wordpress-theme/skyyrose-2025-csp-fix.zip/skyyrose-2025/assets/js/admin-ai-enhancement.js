/**
 * AI Image Enhancement Admin Scripts
 * Handles AJAX calls for image enhancement in WordPress admin
 *
 * @package SkyyRose_2025
 * @version 2.0.0
 */

(function($) {
    'use strict';

    const AIEnhancement = {
        /**
         * Initialize
         */
        init: function() {
            this.bindEvents();
        },

        /**
         * Bind event handlers
         */
        bindEvents: function() {
            // Single image enhancement (media library)
            $(document).on('click', '.skyyrose-enhance-btn', this.enhanceSingleImage);

            // Bulk enhancement (media library)
            if ($('#bulk-action-selector-top').length) {
                $('#bulk-action-selector-top, #bulk-action-selector-bottom').append(
                    '<option value="skyyrose_enhance">Enhance with AI</option>'
                );
                $('#doaction, #doaction2').on('click', this.handleBulkAction);
            }
        },

        /**
         * Enhance single image
         */
        enhanceSingleImage: function(e) {
            e.preventDefault();

            const $button = $(this);
            const attachmentId = $button.data('attachment-id');
            const originalText = $button.text();

            $button.prop('disabled', true).text('Enhancing...');

            $.ajax({
                url: skyyrose_ai.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'skyyrose_enhance_image',
                    nonce: skyyrose_ai.nonce,
                    attachment_id: attachmentId
                },
                success: function(response) {
                    if (response.success) {
                        $button.text('✓ Enhanced').css('color', 'green');
                        setTimeout(function() {
                            location.reload();
                        }, 1000);
                    } else {
                        $button.prop('disabled', false).text(originalText);
                        alert('Enhancement failed: ' + response.data);
                    }
                },
                error: function() {
                    $button.prop('disabled', false).text(originalText);
                    alert('Error: Could not connect to enhancement service');
                }
            });
        },

        /**
         * Handle bulk enhancement action
         */
        handleBulkAction: function(e) {
            const $selector = $(this).siblings('select');
            const action = $selector.val();

            if (action !== 'skyyrose_enhance') {
                return;
            }

            e.preventDefault();

            // Get selected attachment IDs
            const attachmentIds = [];
            $('input[name="media[]"]:checked').each(function() {
                attachmentIds.push($(this).val());
            });

            if (attachmentIds.length === 0) {
                alert('Please select images to enhance');
                return;
            }

            if (!confirm(`Enhance ${attachmentIds.length} image(s) with AI?`)) {
                return;
            }

            AIEnhancement.bulkEnhance(attachmentIds);
        },

        /**
         * Bulk enhance images
         */
        bulkEnhance: function(attachmentIds) {
            const total = attachmentIds.length;
            let completed = 0;
            let failed = 0;

            // Show progress indicator
            const $progress = $('<div class="skyyrose-bulk-progress">' +
                '<div class="progress-bar"><div class="progress-fill" style="width: 0%;"></div></div>' +
                '<p class="progress-text">Processing 0 of ' + total + ' images...</p>' +
                '</div>');

            $('.wrap h1').after($progress);

            // Process images
            $.ajax({
                url: skyyrose_ai.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'skyyrose_bulk_enhance',
                    nonce: skyyrose_ai.nonce,
                    attachment_ids: attachmentIds
                },
                success: function(response) {
                    if (response.success) {
                        completed = response.data.success;
                        failed = response.data.failed;

                        $('.progress-fill').css('width', '100%');
                        $('.progress-text').html(
                            `✓ Enhancement complete!<br>` +
                            `Success: ${completed} | Failed: ${failed}`
                        );

                        setTimeout(function() {
                            location.reload();
                        }, 2000);
                    } else {
                        $('.progress-text').text('✗ Enhancement failed: ' + response.data);
                    }
                },
                error: function() {
                    $('.progress-text').text('✗ Error: Could not connect to enhancement service');
                }
            });
        },

        /**
         * Show preview modal
         */
        showPreview: function(attachmentId, beforeUrl, afterUrl) {
            const modal = `
                <div class="skyyrose-preview-modal">
                    <div class="modal-content">
                        <span class="close">&times;</span>
                        <h2>AI Enhancement Preview</h2>
                        <div class="preview-comparison">
                            <div class="preview-before">
                                <h3>Before</h3>
                                <img src="${beforeUrl}" alt="Before">
                            </div>
                            <div class="preview-after">
                                <h3>After</h3>
                                <img src="${afterUrl}" alt="After">
                            </div>
                        </div>
                        <div class="preview-actions">
                            <button class="button button-secondary close-preview">Cancel</button>
                            <button class="button button-primary apply-enhancement" data-id="${attachmentId}">
                                Apply Enhancement
                            </button>
                        </div>
                    </div>
                </div>
            `;

            $('body').append(modal);

            // Close modal handlers
            $('.skyyrose-preview-modal .close, .close-preview').on('click', function() {
                $('.skyyrose-preview-modal').remove();
            });

            // Apply enhancement
            $('.apply-enhancement').on('click', function() {
                const id = $(this).data('id');
                AIEnhancement.applyEnhancement(id);
            });
        },

        /**
         * Apply enhancement (save to media library)
         */
        applyEnhancement: function(attachmentId) {
            $.ajax({
                url: skyyrose_ai.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'skyyrose_apply_enhancement',
                    nonce: skyyrose_ai.nonce,
                    attachment_id: attachmentId
                },
                success: function(response) {
                    if (response.success) {
                        $('.skyyrose-preview-modal').remove();
                        location.reload();
                    } else {
                        alert('Failed to apply enhancement: ' + response.data);
                    }
                },
                error: function() {
                    alert('Error: Could not save enhancement');
                }
            });
        }
    };

    // Initialize on document ready
    $(document).ready(function() {
        AIEnhancement.init();
    });

})(jQuery);
