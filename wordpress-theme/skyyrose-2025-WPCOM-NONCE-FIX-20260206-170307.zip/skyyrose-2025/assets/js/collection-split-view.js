/**
 * Collection Split-View Enhancement
 * Converts standard grid layout to hybrid split-view with sticky filters and live preview
 *
 * @package SkyyRose_2025
 * @version 2.0.0
 */

(function() {
    'use strict';

    /**
     * Split View Manager
     */
    class CollectionSplitView {
        constructor() {
            this.filterContainer = null;
            this.productsGrid = null;
            this.previewPanel = null;
            this.activeProduct = null;

            this.init();
        }

        init() {
            // Wait for DOM ready
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', () => this.setup());
            } else {
                this.setup();
            }
        }

        setup() {
            // Only run on collection pages
            if (!document.querySelector('.products-grid')) {
                return;
            }

            this.filterContainer = document.querySelector('.filter-container');
            this.productsGrid = document.querySelector('.products-grid');

            if (!this.filterContainer || !this.productsGrid) {
                return;
            }

            // Create split-view layout
            this.createSplitLayout();

            // Add product click handlers for preview
            this.setupProductPreviews();

            // Add filter functionality
            this.setupFilters();
        }

        createSplitLayout() {
            // Wrap existing content in split-view containers
            const wrapper = document.createElement('div');
            wrapper.className = 'split-view-wrapper';
            wrapper.style.cssText = 'display:grid;grid-template-columns:280px 1fr;gap:3rem;max-width:1600px;margin:0 auto;padding:0 2rem;';

            // Create sidebar
            const sidebar = document.createElement('div');
            sidebar.className = 'split-view-sidebar';
            sidebar.style.cssText = 'position:sticky;top:120px;height:fit-content;max-height:calc(100vh - 160px);overflow-y:auto;';

            // Move filters to sidebar
            if (this.filterContainer.parentNode) {
                const filterClone = this.filterContainer.cloneNode(true);
                filterClone.style.cssText = 'flex-direction:column;align-items:flex-start;margin-bottom:0;padding:0;';
                sidebar.appendChild(filterClone);
                this.filterContainer.remove();
                this.filterContainer = filterClone;
            }

            // Add filter sections
            this.addFilterSections(sidebar);

            // Create main content area
            const mainContent = document.createElement('div');
            mainContent.className = 'split-view-main';

            // Wrap products grid
            const gridParent = this.productsGrid.parentNode;
            gridParent.insertBefore(wrapper, this.productsGrid);

            wrapper.appendChild(sidebar);
            wrapper.appendChild(mainContent);
            mainContent.appendChild(this.productsGrid);

            // Create preview panel
            this.createPreviewPanel(mainContent);

            // Apply responsive styles
            this.applyResponsiveStyles();
        }

        addFilterSections(sidebar) {
            const priceSection = this.createFilterSection('Price Range', [
                { label: 'Under $100', min: 0, max: 100 },
                { label: '$100 - $250', min: 100, max: 250 },
                { label: '$250 - $500', min: 250, max: 500 },
                { label: 'Over $500', min: 500, max: 999999 }
            ], 'price');

            const collectionSection = this.createFilterSection('Collection', [
                { label: 'All Collections', value: 'all' },
                { label: 'Black Rose', value: 'black-rose' },
                { label: 'Love Hurts', value: 'love-hurts' },
                { label: 'Signature', value: 'signature' }
            ], 'collection');

            const sizeSection = this.createFilterSection('Size', [
                { label: 'XS', value: 'xs' },
                { label: 'S', value: 's' },
                { label: 'M', value: 'm' },
                { label: 'L', value: 'l' },
                { label: 'XL', value: 'xl' }
            ], 'size');

            sidebar.appendChild(priceSection);
            sidebar.appendChild(collectionSection);
            sidebar.appendChild(sizeSection);
        }

        createFilterSection(title, options, type) {
            const section = document.createElement('div');
            section.className = 'filter-section';
            section.style.cssText = 'margin-bottom:2.5rem;padding-bottom:2rem;border-bottom:1px solid rgba(255,255,255,0.1);';

            const heading = document.createElement('h4');
            heading.textContent = title;
            heading.style.cssText = 'color:#fff;font-size:0.9rem;text-transform:uppercase;letter-spacing:2px;margin-bottom:1rem;font-weight:600;';
            section.appendChild(heading);

            options.forEach(option => {
                const filterItem = document.createElement('label');
                filterItem.className = 'filter-item';
                filterItem.style.cssText = 'display:flex;align-items:center;gap:0.75rem;padding:0.6rem 0;cursor:pointer;color:rgba(255,255,255,0.7);font-size:0.9rem;transition:color 0.3s ease;';

                const checkbox = document.createElement('input');
                checkbox.type = 'checkbox';
                checkbox.dataset.filterType = type;
                checkbox.dataset.filterValue = option.value || '';
                checkbox.dataset.filterMin = option.min || '';
                checkbox.dataset.filterMax = option.max || '';
                checkbox.style.cssText = 'width:16px;height:16px;cursor:pointer;';

                const label = document.createElement('span');
                label.textContent = option.label;

                filterItem.appendChild(checkbox);
                filterItem.appendChild(label);
                section.appendChild(filterItem);

                filterItem.addEventListener('mouseenter', function() {
                    this.style.color = '#D4AF37';
                });
                filterItem.addEventListener('mouseleave', function() {
                    if (!checkbox.checked) {
                        this.style.color = 'rgba(255,255,255,0.7)';
                    }
                });
            });

            return section;
        }

        setupProductPreviews() {
            const productCards = document.querySelectorAll('.product-card');
            productCards.forEach(card => {
                card.addEventListener('click', (e) => {
                    if (e.target.classList.contains('add-btn')) {
                        return;
                    }
                    this.showPreview(card);
                });
            });
        }

        createPreviewPanel(container) {
            this.previewPanel = document.createElement('div');
            this.previewPanel.className = 'preview-panel';
            this.previewPanel.style.cssText = 'position:fixed;right:0;top:0;width:500px;height:100vh;background:rgba(0,0,0,0.95);backdrop-filter:blur(20px);border-left:1px solid rgba(255,255,255,0.1);z-index:1000;transform:translateX(100%);transition:transform 0.4s cubic-bezier(0.2,0.8,0.2,1);overflow-y:auto;padding:3rem 2rem;';

            const closeBtn = document.createElement('button');
            closeBtn.textContent = '×';
            closeBtn.className = 'preview-close';
            closeBtn.style.cssText = 'position:absolute;top:1.5rem;right:1.5rem;background:transparent;border:none;color:#fff;font-size:2.5rem;cursor:pointer;line-height:1;padding:0;width:40px;height:40px;display:flex;align-items:center;justify-content:center;transition:transform 0.3s ease;';
            closeBtn.addEventListener('click', () => this.hidePreview());

            const previewContent = document.createElement('div');
            previewContent.className = 'preview-content';

            this.previewPanel.appendChild(closeBtn);
            this.previewPanel.appendChild(previewContent);
            document.body.appendChild(this.previewPanel);

            const backdrop = document.createElement('div');
            backdrop.className = 'preview-backdrop';
            backdrop.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:999;opacity:0;pointer-events:none;transition:opacity 0.4s ease;';
            backdrop.addEventListener('click', () => this.hidePreview());
            document.body.appendChild(backdrop);
            this.previewBackdrop = backdrop;
        }

        showPreview(card) {
            const productImage = card.querySelector('.card-image-wrapper img');
            const productTitle = card.querySelector('.product-title');
            const productPrice = card.querySelector('.product-price');

            const previewContent = this.previewPanel.querySelector('.preview-content');
            
            // Clear existing content safely
            while (previewContent.firstChild) {
                previewContent.removeChild(previewContent.firstChild);
            }

            if (productImage) {
                const img = document.createElement('img');
                img.src = productImage.src;
                img.alt = productImage.alt;
                img.style.cssText = 'width:100%;height:400px;object-fit:cover;border-radius:4px;margin-bottom:2rem;';
                previewContent.appendChild(img);
            }

            if (productTitle) {
                const title = document.createElement('h2');
                title.textContent = productTitle.textContent;
                title.style.cssText = 'font-family:"Playfair Display",serif;font-size:2rem;color:#fff;margin-bottom:1rem;';
                previewContent.appendChild(title);
            }

            if (productPrice) {
                const price = document.createElement('p');
                price.textContent = productPrice.textContent;
                price.style.cssText = 'font-size:1.5rem;color:#D4AF37;margin-bottom:2rem;letter-spacing:1px;';
                previewContent.appendChild(price);
            }

            const addBtn = document.createElement('button');
            addBtn.textContent = 'ADD TO CART';
            addBtn.style.cssText = 'width:100%;padding:1.2rem;background:linear-gradient(135deg,#8B0000,#4a0000);border:1px solid rgba(255,255,255,0.1);color:#fff;text-transform:uppercase;letter-spacing:3px;cursor:pointer;font-weight:600;border-radius:2px;';
            previewContent.appendChild(addBtn);

            this.previewPanel.style.transform = 'translateX(0)';
            this.previewBackdrop.style.opacity = '1';
            this.previewBackdrop.style.pointerEvents = 'auto';
            document.body.style.overflow = 'hidden';
        }

        hidePreview() {
            this.previewPanel.style.transform = 'translateX(100%)';
            this.previewBackdrop.style.opacity = '0';
            this.previewBackdrop.style.pointerEvents = 'none';
            document.body.style.overflow = '';
        }

        setupFilters() {
            const checkboxes = this.filterContainer.querySelectorAll('input[type="checkbox"]');
            checkboxes.forEach(checkbox => {
                checkbox.addEventListener('change', () => this.applyFilters());
            });
        }

        applyFilters() {
            const activeFilters = { price: [], collection: [], size: [] };
            const checkboxes = this.filterContainer.querySelectorAll('input[type="checkbox"]:checked');

            checkboxes.forEach(checkbox => {
                const type = checkbox.dataset.filterType;
                const value = checkbox.dataset.filterValue;
                const min = checkbox.dataset.filterMin;
                const max = checkbox.dataset.filterMax;

                if (type === 'price') {
                    activeFilters.price.push({ min: parseFloat(min), max: parseFloat(max) });
                } else if (type && value) {
                    activeFilters[type].push(value);
                }
            });

            const productCards = document.querySelectorAll('.product-card');
            productCards.forEach(card => {
                let show = true;

                if (activeFilters.price.length > 0) {
                    const priceElement = card.querySelector('.product-price');
                    const priceText = priceElement ? priceElement.textContent : '';
                    const price = parseFloat(priceText.replace(/[^0-9.]/g, ''));
                    const priceMatch = activeFilters.price.some(range =>
                        price >= range.min && price <= range.max
                    );
                    if (!priceMatch) show = false;
                }

                if (activeFilters.collection.length > 0 && !activeFilters.collection.includes('all')) {
                    const collection = card.dataset.collection || '';
                    if (!activeFilters.collection.includes(collection)) show = false;
                }

                card.style.display = show ? '' : 'none';
            });
        }

        applyResponsiveStyles() {
            const style = document.createElement('style');
            style.textContent = `@media (max-width:1024px){.split-view-wrapper{grid-template-columns:1fr!important}.split-view-sidebar{position:relative!important;top:0!important;max-height:none!important;margin-bottom:3rem}.preview-panel{width:100%!important}}`;
            document.head.appendChild(style);
        }
    }

    new CollectionSplitView();

})();
