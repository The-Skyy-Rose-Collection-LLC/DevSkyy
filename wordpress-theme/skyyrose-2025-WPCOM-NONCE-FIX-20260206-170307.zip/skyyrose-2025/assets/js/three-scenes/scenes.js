/**
 * SkyyRose 3D Immersive Scenes
 * Three.js + Babylon.js + GSAP configurations for collection experiences
 *
 * @package SkyyRose_2025
 * @version 2.0.0
 */

(function() {
    'use strict';

    // Wait for dependencies
    if (typeof THREE === 'undefined' || typeof BABYLON === 'undefined' || typeof gsap === 'undefined') {
        console.error('SkyyRose Scenes: Missing dependencies (Three.js, Babylon.js, or GSAP)');
        return;
    }

    /**
     * Scene Manager
     * Initializes and manages all 3D scenes
     */
    class SkyyRoseSceneManager {
        constructor(container, config) {
            this.container = container;
            this.config = config;
            this.canvas = container.querySelector('.scene-canvas');
            this.loadingElement = container.querySelector('.scene-loading');

            // Scene components
            this.scene = null;
            this.camera = null;
            this.renderer = null;
            this.controls = null;
            this.physicsEngine = null;
            this.hotspots = [];
            this.animationFrameId = null;

            this.init();
        }

        async init() {
            try {
                // Setup Three.js
                this.setupRenderer();
                this.setupCamera();
                this.setupLights();

                // Load scene based on type
                await this.loadScene();

                // Setup physics if enabled
                if (this.config.enablePhysics) {
                    await this.setupPhysics();
                }

                // Setup scroll animations if enabled
                if (this.config.enableScrollTrigger) {
                    this.setupScrollTrigger();
                }

                // Setup camera controls
                this.setupControls();

                // Add hotspots
                this.addHotspots();

                // Start render loop
                this.animate();

                // Hide loading
                this.loadingElement.style.display = 'none';

            } catch (error) {
                console.error('SkyyRose Scene initialization error:', error);
                this.showError('Failed to load 3D experience. Please refresh the page.');
            }
        }

        setupRenderer() {
            this.renderer = new THREE.WebGLRenderer({
                canvas: this.canvas,
                antialias: true,
                alpha: true,
                powerPreference: 'high-performance'
            });

            this.renderer.setSize(this.container.clientWidth, this.container.clientHeight);
            this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
            this.renderer.shadowMap.enabled = true;
            this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
            this.renderer.outputEncoding = THREE.sRGBEncoding;
            this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
            this.renderer.toneMappingExposure = 1.2;
        }

        setupCamera() {
            const aspect = this.container.clientWidth / this.container.clientHeight;
            this.camera = new THREE.PerspectiveCamera(75, aspect, 0.1, 1000);

            // Default position (adjusted per scene)
            this.camera.position.set(0, 5, 10);
        }

        setupLights() {
            this.scene = new THREE.Scene();

            // Ambient light
            const ambientLight = new THREE.AmbientLight(0xffffff, this.config.ambientLight || 0.5);
            this.scene.add(ambientLight);

            // Fog
            if (this.config.fogDensity > 0) {
                this.scene.fog = new THREE.FogExp2(0x000000, this.config.fogDensity);
            }
        }

        async loadScene() {
            switch (this.config.sceneType) {
                case 'black_rose':
                    await this.createBlackRoseScene();
                    break;
                case 'love_hurts':
                    await this.createLoveHurtsScene();
                    break;
                case 'signature':
                    await this.createSignatureScene();
                    break;
                default:
                    throw new Error('Unknown scene type: ' + this.config.sceneType);
            }
        }

        /**
         * BLACK ROSE SCENE
         * Futuristic rose garden with black/white/metallic aesthetic
         */
        async createBlackRoseScene() {
            // Directional light (moonlight effect)
            const moonLight = new THREE.DirectionalLight(0xccccff, 1.5);
            moonLight.position.set(10, 20, 10);
            moonLight.castShadow = true;
            moonLight.shadow.camera.left = -50;
            moonLight.shadow.camera.right = 50;
            moonLight.shadow.camera.top = 50;
            moonLight.shadow.camera.bottom = -50;
            moonLight.shadow.mapSize.width = 2048;
            moonLight.shadow.mapSize.height = 2048;
            this.scene.add(moonLight);

            // Accent lights (red metallic glow)
            const accentLight1 = new THREE.PointLight(0x8B0000, 2, 20);
            accentLight1.position.set(-5, 2, 5);
            this.scene.add(accentLight1);

            const accentLight2 = new THREE.PointLight(0x8B0000, 2, 20);
            accentLight2.position.set(5, 2, -5);
            this.scene.add(accentLight2);

            // Ground (reflective black surface)
            const groundGeometry = new THREE.PlaneGeometry(100, 100);
            const groundMaterial = new THREE.MeshStandardMaterial({
                color: 0x111111,
                metalness: 0.9,
                roughness: 0.1
            });
            const ground = new THREE.Mesh(groundGeometry, groundMaterial);
            ground.rotation.x = -Math.PI / 2;
            ground.receiveShadow = true;
            this.scene.add(ground);

            // Create futuristic rose structures
            const roseGroup = new THREE.Group();

            for (let i = 0; i < 15; i++) {
                const rose = this.createFuturisticRose();
                const angle = (i / 15) * Math.PI * 2;
                const radius = 10 + Math.random() * 10;

                rose.position.x = Math.cos(angle) * radius;
                rose.position.z = Math.sin(angle) * radius;
                rose.position.y = 0;
                rose.rotation.y = Math.random() * Math.PI * 2;
                rose.scale.setScalar(0.5 + Math.random() * 0.5);

                roseGroup.add(rose);
            }

            this.scene.add(roseGroup);

            // Floating particles
            this.createParticleSystem(0xffffff, 200);

            // Camera position
            this.camera.position.set(0, 8, 20);
            this.camera.lookAt(0, 2, 0);
        }

        createFuturisticRose() {
            const rose = new THREE.Group();

            // Stem (metallic)
            const stemGeometry = new THREE.CylinderGeometry(0.05, 0.08, 3, 8);
            const stemMaterial = new THREE.MeshStandardMaterial({
                color: 0x222222,
                metalness: 0.8,
                roughness: 0.2
            });
            const stem = new THREE.Mesh(stemGeometry, stemMaterial);
            stem.position.y = 1.5;
            stem.castShadow = true;
            rose.add(stem);

            // Rose petals (black with red edges)
            const petalGroup = new THREE.Group();
            const petalGeometry = new THREE.SphereGeometry(0.3, 16, 16);
            const petalMaterial = new THREE.MeshStandardMaterial({
                color: 0x000000,
                emissive: 0x8B0000,
                emissiveIntensity: 0.3,
                metalness: 0.6,
                roughness: 0.4
            });

            for (let i = 0; i < 8; i++) {
                const petal = new THREE.Mesh(petalGeometry, petalMaterial);
                const angle = (i / 8) * Math.PI * 2;
                petal.position.x = Math.cos(angle) * 0.5;
                petal.position.z = Math.sin(angle) * 0.5;
                petal.scale.set(1, 0.5, 0.3);
                petal.rotation.y = angle;
                petal.castShadow = true;
                petalGroup.add(petal);
            }

            petalGroup.position.y = 3;
            rose.add(petalGroup);

            return rose;
        }

        /**
         * LOVE HURTS SCENE
         * Enchanted castle with romantic rose animations (Beauty and the Beast inspired)
         */
        async createLoveHurtsScene() {
            // Soft romantic lighting
            const ambientLight = new THREE.AmbientLight(0xffe6f0, 0.6);
            this.scene.add(ambientLight);

            const spotLight = new THREE.SpotLight(0xffccdd, 2);
            spotLight.position.set(0, 15, 0);
            spotLight.angle = Math.PI / 4;
            spotLight.penumbra = 0.5;
            spotLight.castShadow = true;
            spotLight.shadow.mapSize.width = 2048;
            spotLight.shadow.mapSize.height = 2048;
            this.scene.add(spotLight);

            // Castle floor (marble)
            const floorGeometry = new THREE.PlaneGeometry(50, 50);
            const floorMaterial = new THREE.MeshStandardMaterial({
                color: 0xf5f5dc,
                roughness: 0.3,
                metalness: 0.1
            });
            const floor = new THREE.Mesh(floorGeometry, floorMaterial);
            floor.rotation.x = -Math.PI / 2;
            floor.receiveShadow = true;
            this.scene.add(floor);

            // Glass dome (enchanted rose container)
            const domeGeometry = new THREE.SphereGeometry(2, 32, 32, 0, Math.PI * 2, 0, Math.PI / 2);
            const domeMaterial = new THREE.MeshPhysicalMaterial({
                color: 0xffffff,
                metalness: 0,
                roughness: 0,
                transmission: 0.95,
                thickness: 0.5,
                envMapIntensity: 1
            });
            const dome = new THREE.Mesh(domeGeometry, domeMaterial);
            dome.position.y = 2;
            this.scene.add(dome);

            // Enchanted rose (glowing, animated)
            const enchantedRose = this.createEnchantedRose();
            enchantedRose.position.y = 1;
            this.scene.add(enchantedRose);

            // Floating rose petals
            this.createFloatingPetals();

            // Castle columns
            for (let i = 0; i < 8; i++) {
                const column = this.createCastleColumn();
                const angle = (i / 8) * Math.PI * 2;
                column.position.x = Math.cos(angle) * 15;
                column.position.z = Math.sin(angle) * 15;
                this.scene.add(column);
            }

            // Camera position
            this.camera.position.set(0, 5, 15);
            this.camera.lookAt(0, 2, 0);
        }

        createEnchantedRose() {
            const rose = new THREE.Group();

            // Glowing core
            const coreGeometry = new THREE.SphereGeometry(0.2, 16, 16);
            const coreMaterial = new THREE.MeshStandardMaterial({
                color: 0xff0066,
                emissive: 0xff0066,
                emissiveIntensity: 2
            });
            const core = new THREE.Mesh(coreGeometry, coreMaterial);
            rose.add(core);

            // Rose petals (romantic pink/red gradient)
            const petalGroup = new THREE.Group();
            const petalGeometry = new THREE.SphereGeometry(0.4, 16, 16);

            for (let i = 0; i < 12; i++) {
                const petalMaterial = new THREE.MeshStandardMaterial({
                    color: 0xB76E79,
                    emissive: 0xff0066,
                    emissiveIntensity: 0.5,
                    roughness: 0.6
                });

                const petal = new THREE.Mesh(petalGeometry, petalMaterial);
                const angle = (i / 12) * Math.PI * 2;
                const layer = Math.floor(i / 4);
                const radius = 0.6 + layer * 0.3;

                petal.position.x = Math.cos(angle) * radius;
                petal.position.z = Math.sin(angle) * radius;
                petal.position.y = layer * 0.2;
                petal.scale.set(1, 0.5, 0.4);
                petal.rotation.y = angle;
                petal.castShadow = true;

                petalGroup.add(petal);
            }

            rose.add(petalGroup);

            // Animate rose glow
            gsap.to(coreMaterial, {
                emissiveIntensity: 3,
                duration: 2,
                repeat: -1,
                yoyo: true,
                ease: 'sine.inOut'
            });

            // Animate rose rotation
            gsap.to(rose.rotation, {
                y: Math.PI * 2,
                duration: 20,
                repeat: -1,
                ease: 'none'
            });

            return rose;
        }

        createFloatingPetals() {
            const petalCount = 30;
            const petalGroup = new THREE.Group();

            for (let i = 0; i < petalCount; i++) {
                const petalGeometry = new THREE.PlaneGeometry(0.3, 0.5);
                const petalMaterial = new THREE.MeshStandardMaterial({
                    color: 0xffb6c1,
                    side: THREE.DoubleSide,
                    transparent: true,
                    opacity: 0.7
                });

                const petal = new THREE.Mesh(petalGeometry, petalMaterial);

                petal.position.x = (Math.random() - 0.5) * 20;
                petal.position.y = Math.random() * 10;
                petal.position.z = (Math.random() - 0.5) * 20;

                petal.rotation.x = Math.random() * Math.PI;
                petal.rotation.y = Math.random() * Math.PI;

                petalGroup.add(petal);

                // Animate floating
                gsap.to(petal.position, {
                    y: petal.position.y + (Math.random() - 0.5) * 5,
                    duration: 3 + Math.random() * 2,
                    repeat: -1,
                    yoyo: true,
                    ease: 'sine.inOut'
                });

                gsap.to(petal.rotation, {
                    z: Math.PI * 2,
                    duration: 5 + Math.random() * 3,
                    repeat: -1,
                    ease: 'none'
                });
            }

            this.scene.add(petalGroup);
        }

        createCastleColumn() {
            const column = new THREE.Group();

            const baseGeometry = new THREE.CylinderGeometry(0.8, 1, 0.5, 16);
            const shaftGeometry = new THREE.CylinderGeometry(0.5, 0.5, 8, 16);
            const capitalGeometry = new THREE.CylinderGeometry(1, 0.5, 0.5, 16);

            const columnMaterial = new THREE.MeshStandardMaterial({
                color: 0xd4d4d4,
                roughness: 0.8,
                metalness: 0.1
            });

            const base = new THREE.Mesh(baseGeometry, columnMaterial);
            base.position.y = 0.25;
            base.castShadow = true;

            const shaft = new THREE.Mesh(shaftGeometry, columnMaterial);
            shaft.position.y = 4.5;
            shaft.castShadow = true;

            const capital = new THREE.Mesh(capitalGeometry, columnMaterial);
            capital.position.y = 9;
            capital.castShadow = true;

            column.add(base, shaft, capital);

            return column;
        }

        /**
         * SIGNATURE SCENE
         * High fashion runway with minimal luxury aesthetic
         */
        async createSignatureScene() {
            // Dramatic spotlight lighting
            const spotLight1 = new THREE.SpotLight(0xffffff, 3);
            spotLight1.position.set(0, 20, 0);
            spotLight1.angle = Math.PI / 6;
            spotLight1.penumbra = 0.3;
            spotLight1.castShadow = true;
            spotLight1.shadow.mapSize.width = 2048;
            spotLight1.shadow.mapSize.height = 2048;
            this.scene.add(spotLight1);

            const spotLight2 = new THREE.SpotLight(0xD4AF37, 2);
            spotLight2.position.set(10, 15, 10);
            spotLight2.angle = Math.PI / 4;
            spotLight2.penumbra = 0.5;
            this.scene.add(spotLight2);

            // Runway floor (glossy black)
            const runwayGeometry = new THREE.PlaneGeometry(6, 50);
            const runwayMaterial = new THREE.MeshStandardMaterial({
                color: 0x000000,
                metalness: 0.8,
                roughness: 0.1
            });
            const runway = new THREE.Mesh(runwayGeometry, runwayMaterial);
            runway.rotation.x = -Math.PI / 2;
            runway.receiveShadow = true;
            this.scene.add(runway);

            // Gold accent strips
            const stripGeometry = new THREE.PlaneGeometry(0.2, 50);
            const stripMaterial = new THREE.MeshStandardMaterial({
                color: 0xD4AF37,
                metalness: 1,
                roughness: 0,
                emissive: 0xD4AF37,
                emissiveIntensity: 0.5
            });

            const strip1 = new THREE.Mesh(stripGeometry, stripMaterial);
            strip1.rotation.x = -Math.PI / 2;
            strip1.position.x = -3;
            strip1.position.y = 0.01;
            this.scene.add(strip1);

            const strip2 = new THREE.Mesh(stripGeometry, stripMaterial);
            strip2.rotation.x = -Math.PI / 2;
            strip2.position.x = 3;
            strip2.position.y = 0.01;
            this.scene.add(strip2);

            // Audience seating (minimalist white blocks)
            for (let i = 0; i < 10; i++) {
                const seatLeft = this.createMinimalistSeat();
                seatLeft.position.set(-8, 0.5, -20 + i * 4);
                this.scene.add(seatLeft);

                const seatRight = this.createMinimalistSeat();
                seatRight.position.set(8, 0.5, -20 + i * 4);
                this.scene.add(seatRight);
            }

            // Floating geometric shapes (luxury abstract art)
            this.createFloatingGeometry();

            // Camera position (runway perspective)
            this.camera.position.set(0, 3, 15);
            this.camera.lookAt(0, 1.5, 0);
        }

        createMinimalistSeat() {
            const seatGeometry = new THREE.BoxGeometry(2, 1, 1);
            const seatMaterial = new THREE.MeshStandardMaterial({
                color: 0xffffff,
                roughness: 0.5,
                metalness: 0.1
            });
            const seat = new THREE.Mesh(seatGeometry, seatMaterial);
            seat.castShadow = true;
            seat.receiveShadow = true;
            return seat;
        }

        createFloatingGeometry() {
            const shapes = [];
            const geometries = [
                new THREE.BoxGeometry(1, 1, 1),
                new THREE.SphereGeometry(0.5, 16, 16),
                new THREE.ConeGeometry(0.5, 1, 16),
                new THREE.TorusGeometry(0.5, 0.2, 16, 32)
            ];

            const material = new THREE.MeshStandardMaterial({
                color: 0xD4AF37,
                metalness: 0.9,
                roughness: 0.1,
                emissive: 0xD4AF37,
                emissiveIntensity: 0.3
            });

            for (let i = 0; i < 6; i++) {
                const geometry = geometries[Math.floor(Math.random() * geometries.length)];
                const shape = new THREE.Mesh(geometry, material);

                shape.position.x = (Math.random() - 0.5) * 20;
                shape.position.y = 3 + Math.random() * 8;
                shape.position.z = (Math.random() - 0.5) * 30;

                shape.castShadow = true;
                shapes.push(shape);
                this.scene.add(shape);

                // Animate floating and rotation
                gsap.to(shape.position, {
                    y: shape.position.y + (Math.random() - 0.5) * 3,
                    duration: 3 + Math.random() * 2,
                    repeat: -1,
                    yoyo: true,
                    ease: 'sine.inOut'
                });

                gsap.to(shape.rotation, {
                    x: Math.PI * 2,
                    y: Math.PI * 2,
                    duration: 10 + Math.random() * 5,
                    repeat: -1,
                    ease: 'none'
                });
            }
        }

        createParticleSystem(color, count) {
            const geometry = new THREE.BufferGeometry();
            const positions = new Float32Array(count * 3);

            for (let i = 0; i < count * 3; i += 3) {
                positions[i] = (Math.random() - 0.5) * 50;
                positions[i + 1] = Math.random() * 20;
                positions[i + 2] = (Math.random() - 0.5) * 50;
            }

            geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));

            const material = new THREE.PointsMaterial({
                color: color,
                size: 0.1,
                transparent: true,
                opacity: 0.6
            });

            const particles = new THREE.Points(geometry, material);
            this.scene.add(particles);

            // Animate particles
            gsap.to(particles.rotation, {
                y: Math.PI * 2,
                duration: 60,
                repeat: -1,
                ease: 'none'
            });
        }

        setupControls() {
            // Camera auto-rotate
            if (this.config.autoRotate) {
                const radius = this.camera.position.length();
                const speed = this.config.cameraSpeed || 0.5;

                gsap.to(this.camera.position, {
                    x: Math.cos(Date.now() * 0.001 * speed) * radius,
                    z: Math.sin(Date.now() * 0.001 * speed) * radius,
                    duration: 60 / speed,
                    repeat: -1,
                    ease: 'none',
                    onUpdate: () => {
                        this.camera.lookAt(0, 2, 0);
                    }
                });
            }

            // Mouse interaction (optional - basic orbit)
            let mouseX = 0;
            let mouseY = 0;

            document.addEventListener('mousemove', (event) => {
                mouseX = (event.clientX / window.innerWidth) * 2 - 1;
                mouseY = -(event.clientY / window.innerHeight) * 2 + 1;
            });

            // Apply subtle camera movement based on mouse
            const updateCameraFromMouse = () => {
                this.camera.position.x += (mouseX * 2 - this.camera.position.x) * 0.01;
                this.camera.position.y += (mouseY * 2 + 5 - this.camera.position.y) * 0.01;
            };

            // Add to render loop
            this.mouseUpdate = updateCameraFromMouse;
        }

        async setupPhysics() {
            // Babylon.js physics would be initialized here
            // For now, using GSAP for animations (physics simulation can be added if needed)
        }

        setupScrollTrigger() {
            if (typeof ScrollTrigger === 'undefined') {
                console.warn('GSAP ScrollTrigger not loaded');
                return;
            }

            gsap.registerPlugin(ScrollTrigger);

            // Camera zoom on scroll
            ScrollTrigger.create({
                trigger: this.container,
                start: 'top top',
                end: 'bottom bottom',
                scrub: 1,
                onUpdate: (self) => {
                    const progress = self.progress;
                    this.camera.position.z = 20 - progress * 10;
                    this.camera.position.y = 8 - progress * 3;
                }
            });
        }

        addHotspots() {
            if (!this.config.hotspots || this.config.hotspots.length === 0) {
                return;
            }

            // Hotspots would be added to the 3D scene here
            // This requires WooCommerce product data integration
            // For now, placeholder positions are used
            this.config.hotspots.forEach(hotspot => {
                const position = new THREE.Vector3(
                    hotspot.position_x?.size || 0,
                    hotspot.position_y?.size || 2,
                    hotspot.position_z?.size || 0
                );

                // Create hotspot marker (will be rendered as HTML overlay in final implementation)
            });
        }

        animate() {
            this.animationFrameId = requestAnimationFrame(() => this.animate());

            // Update mouse-based camera movement
            if (this.mouseUpdate) {
                this.mouseUpdate();
            }

            // Render
            this.renderer.render(this.scene, this.camera);
        }

        showError(message) {
            const errorDiv = document.createElement('div');
            errorDiv.style.cssText = 'color: #f44336; text-align: center;';

            const errorText = document.createElement('p');
            errorText.textContent = message;

            errorDiv.appendChild(errorText);
            this.loadingElement.textContent = '';
            this.loadingElement.appendChild(errorDiv);
        }

        destroy() {
            if (this.animationFrameId) {
                cancelAnimationFrame(this.animationFrameId);
            }

            // Clean up Three.js resources
            if (this.scene) {
                this.scene.traverse(object => {
                    if (object.geometry) object.geometry.dispose();
                    if (object.material) {
                        if (Array.isArray(object.material)) {
                            object.material.forEach(material => material.dispose());
                        } else {
                            object.material.dispose();
                        }
                    }
                });
            }

            if (this.renderer) {
                this.renderer.dispose();
            }
        }
    }

    /**
     * Initialize scenes when DOM is ready
     */
    document.addEventListener('DOMContentLoaded', function() {
        const sceneContainers = document.querySelectorAll('.skyyrose-immersive-scene');

        sceneContainers.forEach(container => {
            try {
                const configAttr = container.getAttribute('data-scene-config');
                if (!configAttr) {
                    console.error('SkyyRose Scene: No configuration found');
                    return;
                }

                const config = JSON.parse(configAttr);
                new SkyyRoseSceneManager(container, config);

            } catch (error) {
                console.error('SkyyRose Scene initialization error:', error);
            }
        });

        // Handle window resize
        window.addEventListener('resize', () => {
            sceneContainers.forEach(container => {
                const canvas = container.querySelector('.scene-canvas');
                if (canvas && canvas.sceneManager) {
                    const manager = canvas.sceneManager;
                    manager.camera.aspect = container.clientWidth / container.clientHeight;
                    manager.camera.updateProjectionMatrix();
                    manager.renderer.setSize(container.clientWidth, container.clientHeight);
                }
            });
        });
    });

    // Export to global scope
    window.SkyyRoseSceneManager = SkyyRoseSceneManager;

})();
