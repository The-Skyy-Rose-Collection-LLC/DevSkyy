<?php
/**
 * WooCommerce template
 */
get_header();
?>

<main class="site-main woocommerce-page">
    <div class="container">
        <?php woocommerce_content(); ?>
    </div>
</main>

<?php get_footer(); ?>
