/**
 * SkyyRose 2025 - GSAP Animations
 */
(function() {
    'use strict';
    
    // Wait for DOM and GSAP to load
    document.addEventListener('DOMContentLoaded', function() {
        if (typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined') {
            console.warn('GSAP or ScrollTrigger not loaded');
            return;
        }
        
        gsap.registerPlugin(ScrollTrigger);
        
        // Fade in post cards on scroll
        const postCards = document.querySelectorAll('.post-card');
        if (postCards.length > 0) {
            gsap.from(postCards, {
                scrollTrigger: {
                    trigger: postCards[0],
                    start: 'top 80%',
                },
                opacity: 0,
                y: 50,
                stagger: 0.2,
                duration: 1,
                ease: 'power3.out'
            });
        }
        
        // Parallax effect on thumbnails
        const thumbnails = document.querySelectorAll('.post-thumbnail img, .entry-thumbnail img');
        thumbnails.forEach(function(img) {
            gsap.to(img, {
                scrollTrigger: {
                    trigger: img,
                    start: 'top bottom',
                    end: 'bottom top',
                    scrub: true,
                },
                y: -50,
                ease: 'none'
            });
        });
        
        // Glass panel reveal animation
        const glassPanels = document.querySelectorAll('.glass');
        glassPanels.forEach(function(panel) {
            gsap.from(panel, {
                scrollTrigger: {
                    trigger: panel,
                    start: 'top 90%',
                },
                opacity: 0,
                scale: 0.95,
                duration: 0.8,
                ease: 'power2.out'
            });
        });
    });
})();
