/**
 * Vault Interactive Selector
 * Adds collection and product selection interface to pre-order page
 *
 * @package SkyyRose_2025
 * @version 2.0.0
 */

(function() {
    'use strict';

    class VaultInteractiveSelector {
        constructor() {
            this.selectedCollections = [];
            this.selectedProducts = [];
            this.selectorPanel = null;

            this.init();
        }

        init() {
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', () => this.setup());
            } else {
                this.setup();
            }
        }

        setup() {
            // Only run on vault pages
            if (!document.querySelector('.vault-page')) {
                return;
            }

            this.createSelectorPanel();
            this.setupProductCards();
            this.setupCollectionToggles();
        }

        createSelectorPanel() {
            this.selectorPanel = document.createElement('div');
            this.selectorPanel.className = 'vault-selector-panel';
            this.selectorPanel.style.cssText = 'position:fixed;left:0;top:50%;transform:translateY(-50%);width:400px;background:rgba(0,0,0,0.95);backdrop-filter:blur(20px);border:1px solid rgba(255,255,255,0.1);border-left:none;border-radius:0 8px 8px 0;padding:2rem;z-index:1000;transform:translateX(-100%) translateY(-50%);transition:transform 0.4s cubic-bezier(0.2,0.8,0.2,1);';

            const panelTitle = document.createElement('h3');
            panelTitle.textContent = 'MY PRE-ORDER';
            panelTitle.style.cssText = 'color:#D4AF37;font-family:"Playfair Display",serif;font-size:1.5rem;margin-bottom:1.5rem;text-transform:uppercase;letter-spacing:2px;';
            this.selectorPanel.appendChild(panelTitle);

            const collectionsSection = document.createElement('div');
            collectionsSection.className = 'selected-collections';
            collectionsSection.style.cssText = 'margin-bottom:2rem;';

            const collectionsLabel = document.createElement('h4');
            collectionsLabel.textContent = 'Selected Collections:';
            collectionsLabel.style.cssText = 'color:#fff;font-size:0.9rem;margin-bottom:1rem;text-transform:uppercase;letter-spacing:1px;';
            collectionsSection.appendChild(collectionsLabel);

            const collectionsList = document.createElement('ul');
            collectionsList.className = 'collections-list';
            collectionsList.style.cssText = 'list-style:none;padding:0;margin:0 0 1rem 0;';
            collectionsSection.appendChild(collectionsList);
            this.selectorPanel.appendChild(collectionsSection);

            const productsSection = document.createElement('div');
            productsSection.className = 'selected-products';
            productsSection.style.cssText = 'margin-bottom:2rem;';

            const productsLabel = document.createElement('h4');
            productsLabel.textContent = 'Selected Items:';
            productsLabel.style.cssText = 'color:#fff;font-size:0.9rem;margin-bottom:1rem;text-transform:uppercase;letter-spacing:1px;';
            productsSection.appendChild(productsLabel);

            const productsList = document.createElement('ul');
            productsList.className = 'products-list';
            productsList.style.cssText = 'list-style:none;padding:0;margin:0 0 1rem 0;max-height:200px;overflow-y:auto;';
            productsSection.appendChild(productsList);
            this.selectorPanel.appendChild(productsSection);

            const emailForm = document.createElement('form');
            emailForm.className = 'vault-email-form';
            emailForm.style.cssText = 'border-top:1px solid rgba(255,255,255,0.1);padding-top:1.5rem;';

            const emailInput = document.createElement('input');
            emailInput.type = 'email';
            emailInput.name = 'vault_email';
            emailInput.placeholder = 'Enter your email...';
            emailInput.required = true;
            emailInput.style.cssText = 'width:100%;padding:1rem;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.2);border-radius:4px;color:#fff;font-size:0.9rem;margin-bottom:1rem;';
            emailForm.appendChild(emailInput);

            const submitBtn = document.createElement('button');
            submitBtn.type = 'submit';
            submitBtn.textContent = 'RESERVE MY SPOT';
            submitBtn.style.cssText = 'width:100%;padding:1.2rem;background:linear-gradient(135deg,#8B0000,#4a0000);border:1px solid rgba(255,255,255,0.1);color:#fff;text-transform:uppercase;letter-spacing:3px;cursor:pointer;font-weight:600;border-radius:2px;transition:all 0.3s ease;';
            
            submitBtn.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-2px)';
                this.style.boxShadow = '0 10px 30px rgba(139,0,0,0.5)';
            });
            submitBtn.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0)';
                this.style.boxShadow = 'none';
            });
            
            emailForm.appendChild(submitBtn);
            emailForm.addEventListener('submit', (e) => this.handleSubmit(e));
            this.selectorPanel.appendChild(emailForm);

            const toggleBtn = document.createElement('button');
            toggleBtn.className = 'selector-toggle';
            toggleBtn.textContent = '▶';
            toggleBtn.style.cssText = 'position:absolute;right:-40px;top:50%;transform:translateY(-50%);width:40px;height:80px;background:rgba(139,0,0,0.9);border:1px solid rgba(255,255,255,0.1);border-left:none;border-radius:0 8px 8px 0;color:#D4AF37;font-size:1.2rem;cursor:pointer;transition:all 0.3s ease;display:flex;align-items:center;justify-content:center;';
            
            let panelOpen = false;
            toggleBtn.addEventListener('click', () => {
                panelOpen = !panelOpen;
                if (panelOpen) {
                    this.selectorPanel.style.transform = 'translateX(0) translateY(-50%)';
                    toggleBtn.textContent = '◀';
                } else {
                    this.selectorPanel.style.transform = 'translateX(-100%) translateY(-50%)';
                    toggleBtn.textContent = '▶';
                }
            });
            
            this.selectorPanel.appendChild(toggleBtn);
            document.body.appendChild(this.selectorPanel);

            const style = document.createElement('style');
            style.textContent = '@media (max-width:768px){.vault-selector-panel{width:90vw!important}.selector-toggle{right:-35px!important}}';
            document.head.appendChild(style);
        }

        setupCollectionToggles() {
            const header = document.querySelector('.vault-header');
            if (!header) return;

            const toggleContainer = document.createElement('div');
            toggleContainer.className = 'collection-toggles';
            toggleContainer.style.cssText = 'display:flex;gap:1rem;justify-content:center;margin-top:2rem;flex-wrap:wrap;';

            const collections = [
                { id: 'black-rose', name: 'Black Rose', color: '#8B0000' },
                { id: 'love-hurts', name: 'Love Hurts', color: '#B76E79' },
                { id: 'signature', name: 'Signature', color: '#D4AF37' }
            ];

            collections.forEach(collection => {
                const toggle = document.createElement('button');
                toggle.className = 'collection-toggle';
                toggle.dataset.collection = collection.id;
                toggle.textContent = collection.name;
                toggle.style.cssText = `padding:0.8rem 2rem;background:transparent;border:2px solid ${collection.color};color:${collection.color};text-transform:uppercase;letter-spacing:2px;cursor:pointer;transition:all 0.3s ease;border-radius:30px;font-size:0.85rem;font-weight:600;`;

                toggle.addEventListener('click', () => {
                    const isActive = toggle.classList.contains('active');
                    if (isActive) {
                        toggle.classList.remove('active');
                        toggle.style.background = 'transparent';
                        toggle.style.color = collection.color;
                        this.removeCollection(collection.id);
                    } else {
                        toggle.classList.add('active');
                        toggle.style.background = collection.color;
                        toggle.style.color = '#000';
                        this.addCollection(collection.id, collection.name);
                    }
                    this.filterProductsByCollections();
                });

                toggleContainer.appendChild(toggle);
            });

            header.appendChild(toggleContainer);
        }

        setupProductCards() {
            const productCards = document.querySelectorAll('.vault-card');
            
            productCards.forEach(card => {
                const productId = card.dataset.productId;
                const productName = card.querySelector('.item-name')?.textContent || 'Unknown Product';
                const productCollection = card.dataset.collection || '';

                card.style.cursor = 'pointer';
                card.style.transition = 'all 0.3s ease';

                card.addEventListener('click', () => {
                    const isSelected = card.classList.contains('selected');
                    if (isSelected) {
                        card.classList.remove('selected');
                        card.style.borderColor = 'rgba(255,255,255,0.1)';
                        card.style.boxShadow = 'none';
                        this.removeProduct(productId);
                    } else {
                        card.classList.add('selected');
                        card.style.borderColor = '#D4AF37';
                        card.style.boxShadow = '0 0 20px rgba(212,175,55,0.4)';
                        this.addProduct(productId, productName, productCollection);
                    }
                });

                if (!card.style.border || card.style.border === '') {
                    card.style.border = '2px solid rgba(255,255,255,0.1)';
                }
            });
        }

        addCollection(id, name) {
            if (!this.selectedCollections.find(c => c.id === id)) {
                this.selectedCollections.push({ id, name });
                this.updateCollectionsDisplay();
            }
        }

        removeCollection(id) {
            this.selectedCollections = this.selectedCollections.filter(c => c.id !== id);
            this.updateCollectionsDisplay();
        }

        addProduct(id, name, collection) {
            if (!this.selectedProducts.find(p => p.id === id)) {
                this.selectedProducts.push({ id, name, collection });
                this.updateProductsDisplay();
            }
        }

        removeProduct(id) {
            this.selectedProducts = this.selectedProducts.filter(p => p.id !== id);
            this.updateProductsDisplay();
        }

        updateCollectionsDisplay() {
            const list = this.selectorPanel.querySelector('.collections-list');
            while (list.firstChild) {
                list.removeChild(list.firstChild);
            }

            if (this.selectedCollections.length === 0) {
                const emptyMsg = document.createElement('li');
                emptyMsg.textContent = 'No collections selected';
                emptyMsg.style.cssText = 'color:rgba(255,255,255,0.5);font-size:0.85rem;font-style:italic;';
                list.appendChild(emptyMsg);
            } else {
                this.selectedCollections.forEach(collection => {
                    const item = document.createElement('li');
                    item.textContent = collection.name;
                    item.style.cssText = 'color:#D4AF37;padding:0.5rem 0;font-size:0.9rem;';
                    list.appendChild(item);
                });
            }
        }

        updateProductsDisplay() {
            const list = this.selectorPanel.querySelector('.products-list');
            while (list.firstChild) {
                list.removeChild(list.firstChild);
            }

            if (this.selectedProducts.length === 0) {
                const emptyMsg = document.createElement('li');
                emptyMsg.textContent = 'No items selected';
                emptyMsg.style.cssText = 'color:rgba(255,255,255,0.5);font-size:0.85rem;font-style:italic;';
                list.appendChild(emptyMsg);
            } else {
                this.selectedProducts.forEach(product => {
                    const item = document.createElement('li');
                    item.textContent = product.name;
                    item.style.cssText = 'color:#fff;padding:0.4rem 0;font-size:0.85rem;';
                    list.appendChild(item);
                });
            }
        }

        filterProductsByCollections() {
            if (this.selectedCollections.length === 0) {
                document.querySelectorAll('.vault-card').forEach(card => {
                    card.style.display = '';
                });
                return;
            }

            document.querySelectorAll('.vault-card').forEach(card => {
                const cardCollection = card.dataset.collection || '';
                const shouldShow = this.selectedCollections.some(c => c.id === cardCollection);
                card.style.display = shouldShow ? '' : 'none';
            });
        }

        handleSubmit(e) {
            e.preventDefault();

            const email = e.target.querySelector('input[name="vault_email"]').value;

            const data = {
                email: email,
                collections: this.selectedCollections.map(c => c.id),
                products: this.selectedProducts.map(p => p.id)
            };


            const formData = new FormData();
            formData.append('action', 'skyyrose_vault_preorder');
            formData.append('email', email);
            formData.append('collections', JSON.stringify(data.collections));
            formData.append('products', JSON.stringify(data.products));
            formData.append('nonce', document.querySelector('[name="skyyrose_vault_nonce"]')?.value || '');

            fetch(window.location.origin + '/wp-admin/admin-ajax.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(result => {
                if (result.success) {
                    alert('Thank you! Your pre-order selections have been saved. Check your email for confirmation.');
                    this.resetSelections();
                } else {
                    alert('Something went wrong. Please try again.');
                }
            })
            .catch(error => {
                console.error('Submission error:', error);
                alert('Network error. Please try again.');
            });
        }

        resetSelections() {
            this.selectedCollections = [];
            this.selectedProducts = [];
            
            document.querySelectorAll('.collection-toggle.active').forEach(toggle => {
                toggle.classList.remove('active');
                const color = toggle.dataset.collection === 'black-rose' ? '#8B0000' : 
                             toggle.dataset.collection === 'love-hurts' ? '#B76E79' : '#D4AF37';
                toggle.style.background = 'transparent';
                toggle.style.color = color;
            });

            document.querySelectorAll('.vault-card.selected').forEach(card => {
                card.classList.remove('selected');
                card.style.borderColor = 'rgba(255,255,255,0.1)';
                card.style.boxShadow = 'none';
            });

            this.updateCollectionsDisplay();
            this.updateProductsDisplay();
            this.selectorPanel.querySelector('input[name="vault_email"]').value = '';
        }
    }

    new VaultInteractiveSelector();

})();
