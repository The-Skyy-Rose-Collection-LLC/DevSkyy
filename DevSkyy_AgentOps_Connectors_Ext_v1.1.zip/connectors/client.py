
#!/usr/bin/env python3

import os
import json
import sys
from typing import Any, Dict, Optional

import urllib.request
import urllib.error

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
MCP_ENDPOINT = os.getenv("MCP_ENDPOINT")

def http_json(url: str, payload: Dict[str, Any], headers: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers=headers or {}, method="POST")
    with urllib.request.urlopen(req, timeout=60) as resp:
        raw = resp.read()
        try:
            return json.loads(raw.decode("utf-8"))
        except Exception:
            return {"raw": raw.decode("utf-8", errors="ignore")}

def openai_chat(messages, model="gpt-4o-mini", temperature=0.2) -> Dict[str, Any]:
    """
    Minimal OpenAI-compatible call using the v1/chat/completions endpoint shape.
    The orchestrator will pass in task-specific prompts; this wrapper returns JSON.
    """
    if not OPENAI_API_KEY:
        return {"error": "OPENAI_API_KEY not set"}
    url = "https://api.openai.com/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {OPENAI_API_KEY}",
        "Content-Type": "application/json"
    }
    payload = {
        "model": model,
        "messages": messages,
        "temperature": temperature
    }
    try:
        return http_json(url, payload, headers)
    except urllib.error.HTTPError as e:
        return {"error": f"HTTPError {e.code}", "body": e.read().decode("utf-8", errors="ignore")}
    except Exception as e:
        return {"error": str(e)}

def mcp_call(path: str, body: Dict[str, Any]) -> Dict[str, Any]:
    """
    Generic MCP POST. The endpoint path is appended to MCP_ENDPOINT.
    Example: path="/validate/dependencies"
    """
    if not MCP_ENDPOINT:
        return {"error": "MCP_ENDPOINT not set"}
    url = MCP_ENDPOINT.rstrip("/") + "/" + path.lstrip("/")
    headers = {"Content-Type": "application/json"}
    try:
        return http_json(url, body, headers)
    except urllib.error.HTTPError as e:
        return {"error": f"HTTPError {e.code}", "body": e.read().decode("utf-8", errors="ignore")}
    except Exception as e:
        return {"error": str(e)}

def main():
    """
    CLI usage:
      python connectors/client.py openai '{"messages":[...]}'
      python connectors/client.py mcp '{"path":"validate/dependencies","body":{...}}'
    """
    if len(sys.argv) < 3:
        print(json.dumps({"error": "usage: client.py (openai|mcp) <json>"}))
        sys.exit(1)
    mode = sys.argv[1].strip().lower()
    payload = json.loads(sys.argv[2])
    if mode == "openai":
        messages = payload.get("messages", [])
        model = payload.get("model", "gpt-4o-mini")
        temperature = payload.get("temperature", 0.2)
        out = openai_chat(messages, model=model, temperature=temperature)
    elif mode == "mcp":
        path = payload.get("path", "/ping")
        body = payload.get("body", {})
        out = mcp_call(path, body)
    else:
        out = {"error": f"unknown mode {mode}"}
    print(json.dumps(out, ensure_ascii=False))

if __name__ == "__main__":
    main()
