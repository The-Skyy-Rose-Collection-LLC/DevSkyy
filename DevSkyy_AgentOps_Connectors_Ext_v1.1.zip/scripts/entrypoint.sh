
#!/usr/bin/env bash
set -euo pipefail

ROLE="${1:-${AGENT_ROLE:-unknown}}"
echo "🚀 Agent starting: ${ROLE}"
echo "📁 Workspace: $(pwd)"
mkdir -p reports reports/visuals

# Route to Python runner (with connectors)
python3 /workspace/scripts/agent_runner.py "${ROLE}" || true

# Auto-commit only from coordinator
if [[ "${ROLE}" == "coordinator" ]]; then
  /workspace/scripts/commit_and_push.sh || true
fi

echo "✅ Agent finished: ${ROLE}"
