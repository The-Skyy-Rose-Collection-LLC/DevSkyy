
#!/usr/bin/env bash
set -euo pipefail

: "${GIT_USER_NAME:=AgentOps Bot}"
: "${GIT_USER_EMAIL:=agentops@skyyrosellc.com}"
: "${GITHUB_TOKEN:=}"

git config user.name "$GIT_USER_NAME"
git config user.email "$GIT_USER_EMAIL"

if [[ -n "$(git status --porcelain)" ]]; then
  git add -A
  git commit -m "AgentOps: connectors integration artifacts on 2025-11-11" || true

  if git remote get-url origin >/dev/null 2>&1; then
    REMOTE_URL=$(git remote get-url origin)
  else
    REMOTE_URL="https://github.com/The-Skyy-Rose-Collection-LLC/DevSkyy.git"
    if [[ -n "$GITHUB_TOKEN" ]]; then
      REMOTE_URL="https://$GITHUB_TOKEN@github.com/The-Skyy-Rose-Collection-LLC/DevSkyy.git"
    fi
    git remote add origin "$REMOTE_URL" || true
  fi

  CURRENT_BRANCH=$(git rev-parse --abbrev-ref HEAD)
  git push origin "$CURRENT_BRANCH" || true
else
  echo "No changes to commit."
fi
