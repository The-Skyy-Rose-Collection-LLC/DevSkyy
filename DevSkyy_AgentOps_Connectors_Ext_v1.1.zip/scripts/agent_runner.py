
#!/usr/bin/env python3
import os, json, sys, subprocess, shutil
from pathlib import Path

WORKDIR = Path(os.getenv("WORKDIR", "/workspace"))
REPORTS = WORKDIR / "reports"
VISUALS = REPORTS / "visuals"
CONNECTOR = WORKDIR / "connectors" / "client.py"

def write(path: Path, content: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")

def run(cmd):
    return subprocess.run(cmd, shell=True, check=False, capture_output=True, text=True)

def role_architect():
    # Use MCP to validate dependency graph if available
    if os.getenv("MCP_ENDPOINT"):
        payload = {
            "path": "validate/dependencies",
            "body": {"repo": str(WORKDIR), "scan": True}
        }
        out = run(f'python3 "{CONNECTOR}" mcp \'{json.dumps(payload)}\'')
        write(REPORTS / "dependency-graph.json", out.stdout or out.stderr)
    # Generate diagram placeholder
    write(VISUALS / "dependency_graph.mmd", "graph TD; Repo-->Stacks; Stacks-->Tools; Tools-->Artifacts;")
    write(REPORTS / "architecture.md", "# Architecture Overview\n\n- Auto-detected stacks and tools.\n- See visuals/dependency_graph.mmd")

def role_developer():
    # Ask OpenAI to draft a change set plan (never commits secrets)
    if os.getenv("OPENAI_API_KEY"):
        messages = [
            {"role": "system", "content": "You are a repository developer assistant. Return a concise plan JSON for safe changes."},
            {"role": "user", "content": "Scan repo and identify missing manifests/tests; propose a minimal safe change plan."}
        ]
        payload = {"messages": messages, "model": "gpt-4o-mini", "temperature": 0.1}
        out = run(f'python3 "{CONNECTOR}" openai \'{json.dumps(payload)}\'')
        write(REPORTS / "developer_openai_plan.json", out.stdout or out.stderr)
    write(REPORTS / "developer_changes.md", "# Developer Changes\n\n- Planned fixes recorded here.")

def role_tester():
    # Run minimal smoke tests if manifests exist (placeholder hooks)
    results = {"build": "skipped", "tests": "skipped"}
    if (WORKDIR / "package.json").exists():
        results["build"] = run("npm -v && node -v").stdout
    if list(WORKDIR.glob("**/pyproject.toml")) or list(WORKDIR.glob("**/requirements.txt")):
        results["tests"] = run("python3 -V").stdout
    write(REPORTS / "test_report.md", "# Test Report\n\n```\n" + json.dumps(results, indent=2) + "\n```")

def role_security():
    # Basic check with MCP if available
    if os.getenv("MCP_ENDPOINT"):
        payload = {"path": "audit/security", "body": {"repo": str(WORKDIR)}}
        out = run(f'python3 "{CONNECTOR}" mcp \'{json.dumps(payload)}\'')
        write(REPORTS / "security_audit.json", out.stdout or out.stderr)
    write(REPORTS / "security_audit.md", "# Security Audit\n\n- See security_audit.json for MCP results (if any).")

def role_documentarian():
    write(REPORTS / "documentation_summary.md", "# Documentation Summary\n\n- README/CHANGELOG to be updated by pipeline policies.")

def role_coordinator():
    # Ensure some summary exists
    write(REPORTS / "release_summary.md", "# Release Summary\n\n- All agents executed. See /reports/* for artifacts.")

def main():
    role = (sys.argv[1] if len(sys.argv) > 1 else os.getenv("AGENT_ROLE","unknown")).lower()
    REPORTS.mkdir(parents=True, exist_ok=True)
    VISUALS.mkdir(parents=True, exist_ok=True)
    if role == "architect":
        role_architect()
    elif role == "developer":
        role_developer()
    elif role == "tester":
        role_tester()
    elif role == "security":
        role_security()
    elif role == "documentarian":
        role_documentarian()
    elif role == "coordinator":
        role_coordinator()
    else:
        print(f"Unknown role: {role}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
