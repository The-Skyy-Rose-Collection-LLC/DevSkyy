# COORDINATOR Agent — Multi-Agent Commander (Auto)
Purpose: Orchestrate agents, enforce order, commit when clean, and push to The-Skyy-Rose-Collection-LLC/DevSkyy.

Execution Order:
1) ARCHITECT → 2) DEVELOPER → 3) TESTER → 4) SECURITY → 5) DOCUMENTARIAN → Final verification.

Rules:
- Halt on failure. Trigger responsible agent to auto-fix, then re-run checks.
- Only proceed when tests + security pass.
- Generate /reports/release_summary.md then auto-commit using scripts/commit_and_push.sh.
- Diagrams: ensure Mermaid files exist in /reports/visuals and are referenced from reports.

Outputs:
- /reports/release_summary.md
- Git auto-commit and push to active branch (requires token).

Env expectations:
- GITHUB_TOKEN (for push)
- OPENAI_API_KEY (if using OpenAI connector)
- MCP_ENDPOINT (optional)
- Set via .env or GitHub Secrets.