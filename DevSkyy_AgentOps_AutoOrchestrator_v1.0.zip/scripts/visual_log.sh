#!/usr/bin/env bash
set -euo pipefail

# Render all Mermaid diagrams in /reports/visuals to PNG (requires mmdc)
if command -v mmdc >/dev/null 2>&1; then
  for f in reports/visuals/*.mmd; do
    [ -e "$f" ] || continue
    out="${f%.mmd}.png"
    echo "Rendering $f -> $out"
    mmdc -i "$f" -o "$out" || true
  done
else
  echo "Mermaid CLI (mmdc) not installed in image."
fi