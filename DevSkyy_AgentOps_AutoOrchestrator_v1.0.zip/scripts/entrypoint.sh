#!/usr/bin/env bash
set -euo pipefail

ROLE="${1:-${AGENT_ROLE:-unknown}}"

echo "🚀 Agent starting: ${ROLE}"
echo "📁 Workspace: $(pwd)"
echo ""

mkdir -p reports reports/visuals

# Simple role behavior placeholders (replace with your agent runner)
case "$ROLE" in
  architect)
    echo "# Architecture Overview" > reports/architecture.md
    echo "Autodetected stack will be summarized here." >> reports/architecture.md
    cat > reports/visuals/dependency_graph.mmd <<'EOF'
graph TD
  A[Repo] -->|detects| B[Languages]
  B --> C[Build Tools]
  C --> D[Artifacts]
EOF
    ;;
  developer)
    echo "# Developer Changes" > reports/developer_changes.md
    echo "Planned file updates and fixes recorded here." >> reports/developer_changes.md
    ;;
  tester)
    echo "# Test Report" > reports/test_report.md
    echo "All tests passed (placeholder). Replace with your CI runner." >> reports/test_report.md
    cat > reports/visuals/build_flow.mmd <<'EOF'
flowchart LR
  build-->test-->package
EOF
    ;;
  security)
    echo "# Security Audit" > reports/security_audit.md
    echo "No critical issues found (placeholder). Replace with your scanner." >> reports/security_audit.md
    ;;
  documentarian)
    echo "# Documentation Summary" > reports/documentation_summary.md
    echo "Docs refreshed (placeholder)." >> reports/documentation_summary.md
    ;;
  coordinator)
    echo "# Release Summary" > reports/release_summary.md
    echo "All agents completed. See reports/* for details." >> reports/release_summary.md
    ./scripts/commit_and_push.sh || true
    ;;
  *)
    echo "Unknown role: ${ROLE}"
    exit 1
    ;;
esac

echo "✅ Agent finished: ${ROLE}"